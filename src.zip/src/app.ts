import * as fs from "fs";
import * as readLine from "readline";
const createInterface = readLine.createInterface;
const createReadStream = fs.createReadStream;

import Slide from "./Slide";
import Photo from "./Photo";
import Slideshow from "./Slideshow";

const files: string[] = [
  "a_example",
  "b_lovely_landscapes",
  "c_memorable_moments",
  "d_pet_pictures",
  "e_shiny_selfies"
];

const file: string =
  files[process.argv.length > 2 ? parseInt(process.argv[2]) : 4];

const lineReader: readLine.Interface = createInterface({
  input: createReadStream("in/" + file + ".txt")
});

var slideshow: Slideshow = new Slideshow();
var allPhotos: Photo[] = [];
var count: number = 0;

lineReader.on("line", readSlideshow);

function readSlideshow(line): void {
  if (count === 0) readDescLine(line);
  else readPhotoLine(line, count);
  count++;
  if (count === 1 + slideshow.num) start();
}

function readDescLine(line: string): void {
  slideshow.num = parseInt(line, 10);
}

function readPhotoLine(line: string, count: number) {
  let pieces: string[] = line.split(" ");
  let orientation: string = pieces[0];
  let numTags: number = parseInt(pieces[1], 10);
  var tags: string[] = [];
  const photosParsed = pieces.forEach(
    (line: string, index: number): void => {
      if (index < 2) return;
      tags.push(line);
    }
  );
  if (numTags !== tags.length) console.log("Tiakane");
  let photo: Photo = new Photo(tags, numTags, orientation, count);
  allPhotos.push(photo);
}

function start(): void {
  var vQueue: Photo = null;
  var slides: Slide[] = [];
  allPhotos.forEach((photo: Photo, index: number) => {
    if (photo.orientation === "V") {
      if (vQueue != null) {
        slides.push(new Slide([vQueue, photo]));
        vQueue = null;
      } else {
        vQueue = photo;
      }
    } else {
      slides.push(new Slide([photo]));
    }
  });
  slideshow = new Slideshow(slides);
  write();
  // var mushrooms = pizza.all.filter(c => c.t === "M").length;
  // var tomatoes = pizza.all.length - mushrooms;
  // console.log("mushrooms/tomatoes", mushrooms, tomatoes);
  // var divs = [];
  // for (var i = pizza.max; i >= pizza.l * 2; i--) {
  //   divs = divs.concat(divisors(i));
  // }

  // pizza.all.forEach(cell => {
  //   divs.forEach(d => {
  //     var w = d[0];
  //     var h = d[1];
  //     pizza.takeSlice(cell, w, h);
  //   });
  // });

  // points();
  // write();
}

function points(): void {
  console.log("points", pizza.all.filter(c => c.busy).length, pizza.all.length);
}

function write(): void {
  console.log(slideshow.slides);
  var out = `${slideshow.slides.length}`;
  slideshow.slides.forEach(slide => {
    out += `\n${slide.photos[0].photoId}`;
    if (slide.photos.length > 1) {
      out += ` ${slide.photos[1].photoId}`;
    }
  });
  fs.writeFile(`out/${file}.out`, out, () => {});
}
