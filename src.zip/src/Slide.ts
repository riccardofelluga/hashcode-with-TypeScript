import Photo from "./photo";

export default class Slide {
  public tags: Set<string>;
  public photos: Photo[];

  constructor(photos: Photo[]) {
    this.photos = photos;
    switch (photos.length) {
      case 0:
        console.log("Tiakane hai messo 0 photo");
        return;
      case 1:
        this.tags = new Set([...photos[0].tags]);
        break;
      case 2:
        this.tags = new Set([...photos[0].tags, ...photos[1].tags]);
        break;
      default:
        console.log("Tiakane hai messo piu di 2 photo");
        return;
    }
  }

  interestWith(otherSlide: Slide): number {
    //     ● The number of common tags is 1 → [garden]
    // ● The number of tags in S1
    // , but not is S2
    // is 1 → [cat]
    // ● The number of tags in S2
    // , but not in S1
    // , is 2 → [sele and smile]
    // The interest factor is the minimum of these numbers, so it is 1
    let tagsArray: string[] = [...this.tags];
    var commonTags = tagsArray.filter(x => new Set(otherSlide.tags).has(x));
    var leftUniqueTags = tagsArray.filter(x => !otherSlide.tags.has(x));
    var rightUniqueTags = [...otherSlide.tags].filter(x => !this.tags.has(x));
    return Math.min(
      commonTags.length,
      leftUniqueTags.length,
      rightUniqueTags.length
    );
  }
}
