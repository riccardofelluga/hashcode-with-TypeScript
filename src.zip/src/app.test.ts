import greeter from "./app";

test("greeter returns Hello friend!", () => {
  expect(greeter("friend")).toBe("Hello friend!");
});
